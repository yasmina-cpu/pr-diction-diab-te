import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
from flask_sqlalchemy import SQLAlchemy
import os

app = Flask(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'patients.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    pregnancies = db.Column(db.Integer)
    glucose = db.Column(db.Integer)
    blood_pressure = db.Column(db.Integer)
    skin_thickness = db.Column(db.Integer)
    insulin = db.Column(db.Integer)
    bmi = db.Column(db.Float)
    diabetes_pedigree = db.Column(db.Float)
    age = db.Column(db.Integer)
    result = db.Column(db.String(50))

# Charger modèle et scaler une seule fois
model = pickle.load(open('SVC_model.pkl', 'rb'))
scaler = pickle.load(open('scaler.pkl', 'rb'))

@app.route('/')
def homepage():
    return render_template('diabetes.html')

@app.route('/history')
def history():
    patients = Patient.query.all()
    return render_template('history.html', patients=patients)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        pregnancies = int(request.form['Pregnancies'] or 0)
        glucose = int(request.form['Glucose'] or 0)
        blood_pressure = int(request.form['BloodPressure'] or 0)
        skin_thickness = int(request.form['SkinThickness'] or 0)
        insulin = int(request.form['Insulin'] or 0)
        bmi = float(request.form['BMI'] or 0)
        diabetes_pedigree = float(request.form['DiabetesPedigreeFunction'] or 0)
        age = int(request.form['Age'] or 0)

        features = np.array([[pregnancies, glucose, blood_pressure, skin_thickness,
                              insulin, bmi, diabetes_pedigree, age]])
        features_scaled = scaler.transform(features)

        prediction = model.predict(features_scaled)
        result = 'Positive' if prediction[0] == 1 else 'Negative'

        # Enregistrement
        new_patient = Patient(
            pregnancies=pregnancies,
            glucose=glucose,
            blood_pressure=blood_pressure,
            skin_thickness=skin_thickness,
            insulin=insulin,
            bmi=bmi,
            diabetes_pedigree=diabetes_pedigree,
            age=age,
            result=result
        )
        db.session.add(new_patient)
        db.session.commit()

        return render_template('result.html', prediction_text=result)

    except Exception as e:
        return render_template('result.html', prediction_text=f"Erreur dans les données : {e}")

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
